(* pegGrammar.ml is the parser generated from pegGrammar.peg *)
include PegParserGenFunctor.Make(PegGrammar);;
main () ;;

