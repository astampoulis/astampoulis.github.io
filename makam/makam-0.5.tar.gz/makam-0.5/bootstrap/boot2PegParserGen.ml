include PegParserGenFunctor.Make(Boot2PegParser);;
main ();;
